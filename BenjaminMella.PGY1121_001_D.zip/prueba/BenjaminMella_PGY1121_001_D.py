import os
os.system("cls")
import datetime
import numpy as np

def comprar_departamento(matriz):
    print("Departamentos disponibles:")
    print(matriz)

    departamento = input("Ingrese sigla departamento con el piso (todo junto)")
    piso = int(departamento[1:])
    sigla = departamento[0]

    while matriz[piso-1][ord(sigla)-ord('A')] == 'X':
        print("El departamento ya esta vendido. Ingrese otro.")
        departamento = input("Ingrese sigla departamento con el piso (todo junto) ")
        piso = int(departamento[1:])
        sigla = departamento[0]

    run = input("Ingrese el RUN del comprador (solo números, sin puntos ni guion): ")
    while not run.isdigit():
        print("El RUN ingresado no es válido. Por favor, ingrese solo números.")
        run = input("Ingrese el RUN del comprador (solo números, sin puntos ni guion): ")


    matriz[piso-1][ord(sigla)-ord('A')] = 'X'
    print("La operación se ha realizado correctamente.")

def mostrar_departamentos(matriz):
    print("Departamentos disponibles:")
    print(matriz)

def fin_sesion():
    nombre = input("Ingrese su nombre: ")
    apellido = input("Ingrese su apellido: ")
    fecha_actual = datetime.date.today().strftime("%d/%m/%Y")
    print(f"\nGracias por utilizar el sistema, {nombre} {apellido}!")
    print(f"Fecha actual: {fecha_actual}")

def ver_listado_compradores(matriz):
    print("Listado de compradores:")
    compradores = []
    for piso in range(10):
        for sigla in range(4):
            if matriz[piso][sigla] == 'X':
                compradores.append(matriz[piso, sigla+1] + str(piso+1))

    compradores.sort()
    for comprador in compradores:
        print(comprador)

def mostrar_ventas_totales(matriz):
    precios = np.array([[3800, 3000, 2800, 3500]]) 
    total_ventas = np.count_nonzero(matriz == 'X') * precios.sum()
    print("Ventas totales: " + str(total_ventas) + " UF")

def main():
    matriz_departamentos = np.array([['A', 'B', 'C', 'D']]*10)
    matriz_listado = np.append(matriz_departamentos, [[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]], axis=1)

    while True:
        print("***** CASA FELIZ *****")
        print("[1] Comprar departamento")
        print("[2] Mostrar departamentos disponibles")
        print("[3] Ver listado de compradores")
        print("[4] Mostrar ventas totales")
        print("[5] Salir")

        opcion = input("Ingrese una opción: ")

        if opcion == '1':
            comprar_departamento(matriz_listado)
        elif opcion == '2':
            mostrar_departamentos(matriz_listado)
        elif opcion == '3':
            ver_listado_compradores(matriz_listado)
        elif opcion == '4':
            mostrar_ventas_totales(matriz_listado)
        elif opcion == '5':
            fin_sesion()
            break
        else:
            print("La opción ingresada no es válida. Por favor, inténtelo nuevamente.")

if __name__ == "__main__":
    main()